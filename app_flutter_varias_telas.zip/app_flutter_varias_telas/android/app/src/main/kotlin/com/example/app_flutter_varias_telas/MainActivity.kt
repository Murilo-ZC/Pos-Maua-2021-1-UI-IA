package com.example.app_flutter_varias_telas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
